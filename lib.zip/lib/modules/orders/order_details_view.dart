import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

import '../home/home_controller.dart';

class OrderDetailsView extends StatelessWidget {
  const OrderDetailsView({super.key});

  static const _bg = Color(0xFFF6F3EF);
  static const _card = Color(0xFFFFFFFF);
  static const _text = Color(0xFF1B1B1F);
  static const _textMute = Color(0xFF8B8B92);
  static const _divider = Color(0xFFE9E2DC);
  static const _primary = Color(0xFF6A3F2A);
  static final _r = BorderRadius.circular(16);

  Future<bool> _confirmAction({
    required String title,
    required String message,
    required String okText,
  }) async {
    final res = await Get.dialog<bool>(
      AlertDialog(
        backgroundColor: _card,
        title: Text(title, textDirection: TextDirection.rtl),
        content: Text(message, textDirection: TextDirection.rtl),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () => Get.back(result: true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _primary,
              foregroundColor: Colors.white,
            ),
            child: Text(okText),
          ),
        ],
      ),
      barrierDismissible: false,
    );
    return res == true;
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> o = Map<String, dynamic>.from(
      (Get.arguments ?? {}) as Map,
    );
    final c = Get.find<HomeController>();
    final isOffer = c.isOffer(o);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: _bg,
          elevation: 0,
          iconTheme: const IconThemeData(color: _primary),
          title: Text(
            'طلب #${o['id']}',
            style: const TextStyle(
              color: _primary,
              fontWeight: FontWeight.w900,
            ),
          ),
          centerTitle: true,
        ),
        backgroundColor: _bg,
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (isOffer)
              Obx(() => _row('مهلة القبول', '${c.remainingSeconds(o)} ثانية')),
            _row('العميل', '${o['username'] ?? '-'} — ${o['phone'] ?? '-'}'),
            _row('الفرع', '${o['branch_name'] ?? '-'}'),
            _row('العنوان', '${o['address'] ?? ''}'),
            _row('سعر الطلبية', '${o['total'] ?? 0} د.ل'),
            _row('رسوم التوصيل', '${o['delivery_fee'] ?? 0} د.ل'),
            if ('${o['items_text'] ?? ''}'.trim().isNotEmpty)
              _row('العناصر', '${o['items_text']}'),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () {
                final url = '${o['maps_url'] ?? ''}';
                if (url.isNotEmpty) {
                  launchUrl(
                    Uri.parse(url),
                    mode: LaunchMode.externalApplication,
                  );
                }
              },
              icon: const Icon(Icons.map),
              label: const Text('إظهار الموقع على الخرائط'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
              ),
            ),
            const SizedBox(height: 16),
            Obx(() {
              final busy = c.actionBusy.value;
              final orderId = (o['id'] as num).toInt();
              if (isOffer) {
                final rem = c.remainingSeconds(o);
                return Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: busy || rem <= 0
                            ? null
                            : () async {
                                await c.acceptOffer(o);
                                if (Get.isOverlaysOpen) return;
                                Get.back();
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.shade700,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: const Text('قبول الطلب'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: busy || rem <= 0
                            ? null
                            : () async {
                                await c.rejectOffer(o);
                                Get.back();
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.shade700,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: const Text('رفض'),
                      ),
                    ),
                  ],
                );
              }

              return Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: busy ? null : () => c.markOnTheWay(orderId),
                      icon: const Icon(Icons.route_outlined),
                      label: const Text('بدأ التوصيل'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: busy
                              ? null
                              : () async {
                                  final ok = await _confirmAction(
                                    title: 'تأكيد التسليم',
                                    message: 'هل تم تسليم الطلب #$orderId؟',
                                    okText: 'تأكيد',
                                  );
                                  if (!ok) return;
                                  await c.markDelivered(orderId);
                                  Get.back();
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade600,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text('تم التسليم'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: busy
                              ? null
                              : () async {
                                  final ok = await _confirmAction(
                                    title: 'تأكيد الرفض',
                                    message: 'هل تريد رفض الطلب #$orderId؟',
                                    okText: 'تأكيد',
                                  );
                                  if (!ok) return;
                                  await c.markRejected(
                                    orderId,
                                    reason: 'رفض السائق',
                                  );
                                  Get.back();
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red.shade600,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text('رفض'),
                        ),
                      ),
                    ],
                  ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _row(String k, String v) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: _card,
      borderRadius: _r,
      border: Border.all(color: _divider),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(.04),
          blurRadius: 12,
          offset: const Offset(0, 6),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          k,
          style: const TextStyle(color: _textMute, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          v,
          style: const TextStyle(color: _text, fontWeight: FontWeight.w800),
        ),
      ],
    ),
  );
}
